package tn.esprit.examen.nomPrenomClasseExamen.services;

import tn.esprit.examen.nomPrenomClasseExamen.entities.Client;

import java.util.List;

public interface IServices {
    Client add(Client client);
    void test();
}
