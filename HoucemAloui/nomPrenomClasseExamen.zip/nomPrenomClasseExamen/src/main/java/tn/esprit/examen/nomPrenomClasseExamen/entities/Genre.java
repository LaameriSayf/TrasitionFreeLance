package tn.esprit.examen.nomPrenomClasseExamen.entities;

public enum Genre {
    FEMININ, MASCULIN
}
